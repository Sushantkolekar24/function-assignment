function notiFy() {
    alert ("Name must be filled out")
};  